package Person;

use strict;
use warnings;

use Moose;
use MooseX::StrictConstructor;
use namespace::autoclean;

use DateTime;

with 'Role::Exercise';

has 'first_name' => (
    is       => 'rw',
    isa      => 'Str',
    required => 1,
);

has 'last_name' => (
    is       => 'rw',
    isa      => 'Str',
    required => 1,
);

has 'birth_datetime' => (
    is       => 'rw',
    isa      => 'DateTime',
    required => 1,
);

sub age {
    my $self = shift;

    my $date_diff = DateTime->now - $self->birth_datetime;

    return $date_diff->in_units( 'years' );
}

__PACKAGE__->meta->make_immutable;
1;
