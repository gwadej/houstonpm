package Role::Exercise;

use strict;
use warnings;

use Moose::Role;
use namespace::autoclean;

requires 'age';

has 'is_exercising' => (
    is      => 'rw',
    isa     => 'Bool',
    default => 0,
);

has 'heart_rate' => (
    is      => 'rw',
    isa     => 'Int',
    lazy    => 1,
    builder => '_build_heart_rate',
);

has 'base_heart_rate' => (
    is      => 'ro',
    isa     => 'Int',
    lazy    => 1,
    builder => '_build_base_heart_rate',
);

sub rest {
    my $self = shift;

    $self->is_exercising( 0 );
    $self->heart_rate( $self->base_heart_rate );

    return $self;
}

sub walk {
    my $self = shift;

    $self->is_exercising( 1 );
    $self->heart_rate( $self->base_heart_rate * 2 );

    return $self;
}

sub run {
    my $self = shift;

    $self->is_exercising( 1 );
    $self->heart_rate( $self->base_heart_rate * 3 );

    return $self;
}

sub _build_heart_rate {
    my $self = shift;

    return $self->base_heart_rate;
}

sub _build_base_heart_rate {
    my $self = shift;

    return $self->age * 2;
}

1;
