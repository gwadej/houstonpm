You may have to change the text file formats, this was created on Windows.

This works with PostgreSQL 9.3.

Perl is Windows Strawberry Perl 5.18.

Using pgadmin3, create a database, and a user called PerlMongers, password is
perlmongers.

You will need to edit PerlMongers/DB.pm, for the password, if you changed it,
and the host ip address to connect to.   This has only been tested with TCP/IP
and not UNIX sockets.

After creating the database and user, execute OHLCData.sql and it will create
a pm schema and fill in some data.

Then you can run the test and hopefully it passes.

