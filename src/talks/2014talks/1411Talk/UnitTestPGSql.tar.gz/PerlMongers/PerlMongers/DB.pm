
package PerlMongers::DB;

use strict;
use warnings;

use DBI;
use DBD::Pg;

our $host = "192.168.1.25";
our $dbh;

sub getPgDBH
{
	if (!defined $dbh)
	{
		my $datasource = "DBI:Pg:dbname=PerlMongers;host=$host";

		$dbh = DBI->connect ($datasource,
			"PerlMongers", "perlmongers", { 'RaiseError' => 1 }) 
				or die ("Cannot create DBH");
	}

	return $dbh;
}

1;

__END__

