
package PerlMongers::DataSet;

use strict;
use warnings;

use PerlMongers::DB;
use PerlMongers::Common;

our $OHLCDataSets = qq~"pm"."OHLCDataSets"~;
our $OHLCData     = qq~"pm"."OHLCData"~;

sub _createTempTables
{
	my $dbh = PerlMongers::DB::getPgDBH ();

	my $sql = qq~
CREATE TEMP TABLE $OHLCDataSets
(
  "OHLCDataSetID" serial NOT NULL,
  "Name" character varying(50) NOT NULL,
  "Pair" character(6) NOT NULL,
  period smallint NOT NULL,
  CONSTRAINT "OHLCDataSets_pkey" PRIMARY KEY ("OHLCDataSetID")
)
WITH (
  OIDS=FALSE
);
ALTER TABLE $OHLCDataSets
  OWNER TO "PerlMongers";
~;

	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ();

	$sql = qq~
CREATE TEMP TABLE $OHLCData
(
  ohlc_id serial NOT NULL,
  "OHLCDataSetID" integer NOT NULL,
  "Date" character(20) NOT NULL,
  "EpochTime" integer NOT NULL,
  "Open" double precision NOT NULL,
  "High" double precision NOT NULL,
  "Low" double precision NOT NULL,
  "Close" double precision NOT NULL,
  CONSTRAINT "OHLCData_pkey" PRIMARY KEY (ohlc_id),
  CONSTRAINT "OHLCData_OHLCDataSetID_fkey" FOREIGN KEY ("OHLCDataSetID")
      REFERENCES $OHLCDataSets ("OHLCDataSetID") MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT "OHLCData_OHLCDataSetID_Date" UNIQUE ("OHLCDataSetID", "Date")
)
WITH (
  OIDS=FALSE
);
ALTER TABLE $OHLCData
  OWNER TO "PerlMongers";
CREATE INDEX "Date"
  ON $OHLCData
  USING btree
  ("Date" COLLATE pg_catalog."default");
CREATE INDEX "EpochTime"
  ON $OHLCData
  USING btree
  ("EpochTime");
~;

	$sth = $dbh->prepare ($sql);
	$results = $sth->execute ();

	return;
}

sub createDataSet
{
	my ($name, $pair, $period, @data) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	# create dataset record

	my $sql = qq~INSERT INTO $OHLCDataSets ("Name", "Pair", "period") VALUES (?, ?, ?) RETURNING "OHLCDataSetID";~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($name, $pair, $period);

	my $ref = $sth->fetchrow_arrayref;
	my $dataset_id = $ref->[0];

	$sth->finish ();

	# now insert the actual data

	$sql = qq~INSERT INTO $OHLCData ("OHLCDataSetID", "Date", "EpochTime", "Open", "High", "Low", "Close") VALUES (?, ?, ?, ?, ?, ?, ?);~;
	$sth = $dbh->prepare ($sql);

	foreach my $ref (@data)
	{
		my $etime = PerlMongers::Common::getTimeFromDate ($ref->{'Date'});

		$sth->execute ($dataset_id,
			$ref->{'Date'},
			$etime,
			$ref->{'Open'},
			$ref->{'High'},
			$ref->{'Low'},
			$ref->{'Close'});
	}

	$sth->finish ();

	return $dataset_id;
}

sub getDataSetID
{
	my ($name) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	# create dataset record

	my $sql = qq~SELECT "OHLCDataSetID" FROM $OHLCDataSets WHERE "Name" = ?~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($name);

	my $dataset_id;

	while (my $ref = $sth->fetchrow_hashref)
	{
		$dataset_id = $ref->{'OHLCDataSetID'};
	}

	$sth->finish ();

	if (!defined $dataset_id)
	{
		return 0;
	}

	return $dataset_id;
}

sub deleteDataSet
{
	my ($name) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	my $dataset_id = getDataSetID ($name);
	if ($dataset_id == 0)
	{
		return 0;
	}

	my $sql;
	my $sth;

	# now delete data before dataset

	$sql = qq~DELETE FROM $OHLCData WHERE "OHLCDataSetID" = ?~;
	$sth = $dbh->prepare ($sql);
	$sth->execute ($dataset_id);

	$sth->finish ();

	# now delete the dataset

	$sql = qq~DELETE FROM $OHLCDataSets WHERE "OHLCDataSetID" = ?~;
	$sth = $dbh->prepare ($sql);
	$sth->execute ($dataset_id);

	$sth->finish ();

	return 1;
}

sub loadDataSet
{
	my ($name, $start_date, $end_date, $include_ohlc) = @_;

	if (!defined $include_ohlc || $include_ohlc eq "")
	{
		$include_ohlc = 0;
	}

	my $bDateRange = 0;
	if (defined $start_date && defined $end_date && $start_date ne "" && $end_date ne "")
	{
		$bDateRange = 1;
	}

	my @output;

	my $dataset_id = getDataSetID ($name);
	if ($dataset_id == 0)
	{
		return @output;
	}

	my $dbh = PerlMongers::DB::getPgDBH ();

	# create dataset record

	my $sql;
	my $sth;
	my $results;

	if ($bDateRange)
	{
		$sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? AND "Date" >= ? AND "Date" <= ? ORDER BY "Date" ASC~;
		$sth = $dbh->prepare ($sql);
		$results = $sth->execute ($dataset_id, $start_date, $end_date);
	}
	else
	{
		$sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? ORDER BY "Date" ASC~;
		$sth = $dbh->prepare ($sql);
		$results = $sth->execute ($dataset_id);
	}

	while (my $ref = $sth->fetchrow_hashref)
	{
		my $xref = PerlMongers::Common::copyHashRef ($ref);

		if (!$include_ohlc)
		{
			delete $xref->{'ohlc_id'};
		}

		push (@output, $xref);
	}

	$sth->finish ();

	return @output;
}

sub getAllDataSets
{
	my $dbh = PerlMongers::DB::getPgDBH ();

	my $sql = qq~SELECT * FROM $OHLCDataSets WHERE true ORDER BY "Name"~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ();

	my @output;

	while (my $ref = $sth->fetchrow_hashref)
	{
		my $xref = PerlMongers::Common::copyHashRef ($ref);
		push (@output, $xref);
	}

	$sth->finish ();

	return @output;
}

sub getAllDates
{
	my ($name) = @_;

	if (!defined $name || $name eq "")
	{
		$name = "AUDJPY_daily";
	}

	my $OHLCDataSetsID = getDataSetID ($name);
	my $dbh = PerlMongers::DB::getPgDBH ();

	my $sql = qq~SELECT "Date" FROM $OHLCData WHERE "OHLCDataSetID" = ?~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($OHLCDataSetsID);

	my @output;

	while (my $ref = $sth->fetchrow_hashref)
	{
		my $date = PerlMongers::Common::trim (substr ($ref->{'Date'}, 0, 10));
		push (@output, $date);
	}

	$sth->finish ();

	return @output;
}

sub _getYoungestDate
{
	my ($dataset_id) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	my $sql;
	my $sth;
	my $results;

	my $youngest_date = "";

	# get youngest date
	
	$sql = qq~SELECT "Date" FROM $OHLCData WHERE "OHLCDataSetID" = ? ORDER BY "Date" DESC LIMIT 1~;
	$sth = $dbh->prepare ($sql);
	$results = $sth->execute ($dataset_id);

	if ($sth->rows)
	{
		my $ref = $sth->fetchrow_arrayref;
		$youngest_date = $ref->[0];
	}

	$sth->finish ();

	return $youngest_date;
}

sub updateDataSet
{
	my ($name, $pair, $period, @data) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	my $dataset_id = getDataSetID ($name);

	my $sql;
	my $sth;
	my $results;

	my $youngest_date = _getYoungestDate ($dataset_id); 

	$sql = qq~INSERT INTO $OHLCData ("OHLCDataSetID", "Date", "EpochTime", "Open", "High", "Low", "Close") VALUES (?, ?, ?, ?, ?, ?, ?);~;
	$sth = $dbh->prepare ($sql);

	foreach my $ref (@data)
	{
		if ($youngest_date ne "" && $ref->{'Date'} le $youngest_date) { next; }

		my $etime = PerlMongers::Common::getTimeFromDate ($ref->{'Date'});

		$sth->execute ($dataset_id,
			$ref->{'Date'},
			$etime,
			$ref->{'Open'},
			$ref->{'High'},
			$ref->{'Low'},
			$ref->{'Close'});
	}

	$sth->finish ();

	return 1;
}

sub getDataSetRecord
{
	my ($name) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	# create dataset record

	my $sql = qq~SELECT * FROM $OHLCDataSets WHERE "Name" = ?~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($name);

	if (!$sth->rows)
	{
		$sth->finish ();
		return;
	}

	my $ref = $sth->fetchrow_hashref;
	$sth->finish ();

	my $cref = PerlMongers::Common::copyHashRef ($ref);

	return $cref;
}

sub getDataSetRaw
{
	my ($name) = @_;

	my @output;

	my $dataset_id = getDataSetID ($name);
	if ($dataset_id == 0)
	{
		return @output;
	}

	my $dbh = PerlMongers::DB::getPgDBH ();

	# create dataset record

	my $sql;
	my $sth;
	my $results;

	$sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? ORDER BY "Date" ASC~;
	$sth = $dbh->prepare ($sql);
	$results = $sth->execute ($dataset_id);

	while (my $ref = $sth->fetchrow_hashref)
	{
		my $xref = PerlMongers::Common::copyHashRef ($ref);
		push (@output, $xref);
	}

	$sth->finish ();

	return @output;

}

sub insertDataSetRaw
{
	my ($name, $pair, $period, @data) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	# create dataset record

	my $sql = qq~INSERT INTO $OHLCDataSets ("Name", "Pair", "period") VALUES (?, ?, ?) RETURNING "OHLCDataSetID";~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($name, $pair, $period);

	my $ref = $sth->fetchrow_arrayref;
	my $dataset_id = $ref->[0];

	$sth->finish ();

	# now insert the actual data

	$sql = qq~INSERT INTO $OHLCData ("OHLCDataSetID", "Date", "EpochTime", "Open", "High", "Low", "Close") VALUES (?, ?, ?, ?, ?, ?, ?);~;
	$sth = $dbh->prepare ($sql);

	foreach my $ref (@data)
	{
		$sth->execute ($dataset_id,
			$ref->{'Date'},
			$ref->{'EpochTime'},
			$ref->{'Open'},
			$ref->{'High'},
			$ref->{'Low'},
			$ref->{'Close'});
	}

	$sth->finish ();

	return $dataset_id;
}

my $updateCandleSTH;

sub updateCandle
{
	my ($candle_ref) = @_;

	if (!defined $updateCandleSTH)
	{
		my $dbh = PerlMongers::DB::getPgDBH ();
		my $sql = qq~UPDATE $OHLCData SET "Open" = ?, "High" = ?, "Low" = ?, "Close" = ? WHERE "ohlc_id" = ?~;
		$updateCandleSTH = $dbh->prepare ($sql);
	}

	$updateCandleSTH->execute (
		$candle_ref->{'Open'},
		$candle_ref->{'High'},
		$candle_ref->{'Low'},
		$candle_ref->{'Close'},
		$candle_ref->{'ohlc_id'});
}

sub getCandle
{
	my ($data_set_name, $date) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	my $outref = {};
	$outref->{'rows'} = 0;
	$outref->{'Error'} = 0;

	my $OHLCDataSetID = PerlMongers::DataSet::getDataSetID ($data_set_name);
	if (!defined $OHLCDataSetID)
	{
		$outref->{'Error'} = 1;
		return $outref;
	}

	my $sql;
	my $sth;
	my $results;

	$sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? AND "Date" = ?;~;
	$sth = $dbh->prepare ($sql);
	$results = $sth->execute ($OHLCDataSetID, $date);

	my $rows = $sth->rows;

	$outref = {};
	$outref->{'Error'} = 1;
	$outref->{'rows'} = $rows;

	while (my $ref = $sth->fetchrow_hashref)
	{
		$outref = PerlMongers::Common::copyHashRef ($ref);
		$outref->{'Error'} = 0;
		$outref->{'rows'} = $rows;
		last;
	}

	$sth->finish ();

	return $outref;
}

sub getCandleFloor
{
	my ($data_set_name, $date, $num) = @_;

	if (!defined $num)
	{
		$num = 1;
	}

	my $dbh = PerlMongers::DB::getPgDBH ();

	my $OHLCDataSetID = PerlMongers::DataSet::getDataSetID ($data_set_name);

	my $sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? AND "Date" <= ? ORDER BY "Date" DESC LIMIT ?;~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($OHLCDataSetID, $date, $num);

	my @output;

	while (my $ref = $sth->fetchrow_hashref)
	{
		my $outref;

		$outref = PerlMongers::Common::copyHashRef ($ref);

		push (@output, $outref);
	}

	$sth->finish ();

	return @output;
}

sub getCandles
{
	my ($data_set_name, $start_date, $end_date) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();
	my @output;

	my $OHLCDataSetID = PerlMongers::DataSet::getDataSetID ($data_set_name);
	if (!defined $OHLCDataSetID)
	{
		return @output;
	}

	my $sql;
	my $sth;
	my $results;

	$sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? AND "Date" >= ? AND "Date" <= ? ORDER BY "Date" ASC;~;

	$sth = $dbh->prepare ($sql);
	$results = $sth->execute ($OHLCDataSetID, $start_date, $end_date);

	while (my $ref = $sth->fetchrow_hashref)
	{
		push (@output, PerlMongers::Common::copyHashRef ($ref));
	}

	$sth->finish ();

	return @output;
}

sub getAllCandles
{
	my ($data_set_name) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();
	my @output;

	my $OHLCDataSetID = PerlMongers::DataSet::getDataSetID ($data_set_name);
	if (!defined $OHLCDataSetID)
	{
		return @output;
	}

	my $sql;
	my $sth;
	my $results;

	$sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ?~;

	$sth = $dbh->prepare ($sql);
	$results = $sth->execute ($OHLCDataSetID);

	while (my $ref = $sth->fetchrow_hashref)
	{
		push (@output, PerlMongers::Common::copyHashRef ($ref));
	}

	$sth->finish ();

	return @output;
}

sub getBaseTime
{
	my ($data_set_name) = @_;

	my $dbh = PerlMongers::DB::getPgDBH ();

	my $sql = qq~SELECT "period" FROM $OHLCDataSets WHERE "Name" = ? LIMIT 1;~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($data_set_name);

	my $baseTime = 86400; # assume daily

	while (my $ref = $sth->fetchrow_hashref)
	{
		my $period = $ref->{'period'};
		$baseTime = $period * 60;
		last;
	}

	$sth->finish ();

	return $baseTime;
}

sub getLastCandleOfDay
{
	my ($data_set_name, $date) = @_;

	# 01234567890
	# 2010-01-03

	my $xdate = substr ($date, 0, 10);

	my $dbh = PerlMongers::DB::getPgDBH ();
	my $OHLCDataSetID = getDataSetID ($data_set_name);

	my $sql = qq~SELECT * FROM $OHLCData WHERE "OHLCDataSetID" = ? AND "Date" > ? AND "Date" < ? ORDER BY "Date" DESC LIMIT 1;~;
	my $sth = $dbh->prepare ($sql);
	my $results = $sth->execute ($OHLCDataSetID, $xdate, $xdate . "a");

	my @output;

	my $ref = { 'Date' => $xdate, "Rows" => $sth->rows, "Results" => $results, "Err" => $sth->err, "ErrStr" => $sth->errstr, "OHLCDataSetID" => $OHLCDataSetID, "DataSetName" => $data_set_name };

	if ($sth->rows > 0)
	{
		$ref = $sth->fetchrow_hashref ();
	}

	$sth->finish ();

	return $ref;
}

1;

__END__

