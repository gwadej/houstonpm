package PerlMongers::Common;

use strict;
use warnings;

use Time::Local;
use Carp;

sub copyHashRef
{
	my ($in_ref) = @_;

	my $out_ref = {};

	foreach my $key (keys %$in_ref)
	{
		$out_ref->{$key} = $in_ref->{$key};
	}

	return $out_ref;
}

sub getTimeFromDate
{
	my ($date) = @_;

	my $time = 0;

	# 2012-02-24 23:59:00

	if ($date =~ m/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/)
	{
		my ($year, $mon, $mday, $hour, $min, $sec);

		$year = $1;
		$mon  = $2;
		$mday = $3;
		$hour = $4;
		$min  = $5;
		$sec  = $6;

		if ($mon =~ m/^0(\d)/) { $mon = $1; }
		if ($mday =~ m/^0{\d}/) { $mday = $1; }
		if ($hour =~ m/^0{\d}/) { $hour = $1; }
		if ($min =~ m/^0{\d}/) { $min = $1; }
		if ($sec =~ m/^0{\d}/) { $sec = $1; }

		$year -= 1900;
		$mon --;

		$time = Time::Local::timelocal( $sec, $min, $hour, $mday, $mon, $year );
	}

	return $time;
}

sub ltrim
{
	my ($string) = @_;

	$string =~ s/^\s+//;

	return $string;
}

sub rtrim
{
	my ($string) = @_;

	$string =~ s/\s+$//;

	return $string;
}

sub trim
{
	my ($string) = @_;

	$string = ltrim (rtrim ($string));

	return $string;
}

1;

__END__

