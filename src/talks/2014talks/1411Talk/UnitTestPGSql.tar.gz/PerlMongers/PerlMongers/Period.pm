package PerlMongers::Period;

use strict;
use warnings;

use Time::Local;

sub getTimeFromDate
{
	my ($date) = @_;

	my $year = substr ($date,  0, 4);
	my $mon  = substr ($date,  5, 2);
	my $mday = substr ($date,  8, 2);
	my $hour = substr ($date, 11, 2);
	my $min  = substr ($date, 14, 2);
	my $sec  = substr ($date, 17, 2);

	$mon --;
	$year -= 1900;

	my $time = &Time::Local::timelocal ($sec, $min, $hour, $mday, $mon, $year);

	my ($xsec, $xmin, $xhour, $xmday, $xmon, $xyear, $xwday, $xyday, $xisdst) = localtime($time);

	return $time;
}

sub findMidnightPlusOne
{
	my ($time) = @_;

	my ($xsec, $xmin, $xhour, $xmday, $xmon, $xyear, $xwday, $xyday, $xisdst) = localtime($time);
	$xyear += 1900;

	$time -= ($xhour * 3600);
	$time -= ($xmin * 60);

	if ($xsec > 1)
	{
		$xsec --;

		$time -= $xsec;
	}
	elsif ($xsec == 1)
	{
	}
	else
	{
		$time ++;
	}

	($xsec, $xmin, $xhour, $xmday, $xmon, $xyear, $xwday, $xyday, $xisdst) = localtime($time);
	$xyear += 1900;

	return ($time, $xwday);
}

sub convertTimeToDate
{
	my ($time) = @_;

	my ($xsec, $xmin, $xhour, $xmday, $xmon, $xyear, $xwday, $xyday, $xisdst) = localtime($time);
	$xyear += 1900;
	$xmon ++;

	my $sdate = sprintf ("%04d-%02d-%02d %02d:%02d:%02d", $xyear, $xmon, $xmday, $xhour, $xmin, $xsec);

	return $sdate;
}

sub findOpenDate
{
	my ($date, $target_wday) = @_;

	my $time = &getTimeFromDate ($date);
	my $xwday;

	($time, $xwday) = &findMidnightPlusOne ($time);

	while ($xwday != $target_wday)
	{
		$time -= 2;
		($time, $xwday) = &findMidnightPlusOne ($time);
	}

	return &convertTimeToDate ($time);
}

1;

__END__

